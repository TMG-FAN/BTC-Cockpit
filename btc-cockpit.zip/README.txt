============================================================
  BTC COCKPIT  —  a live Bitcoin dashboard you run yourself
============================================================

What it is
----------
A single dashboard that opens in your web browser and shows live, multi-exchange
Bitcoin data on one screen:

  - Price & volume chart + technical analysis (TradingView)
  - Open interest, aggregated across exchanges
  - Funding rate, aggregated
  - Long / short ratio (1H / 4H / 12H / 24H)
  - Liquidations, aggregated (longs vs shorts)
  - Futures volume (1H / 4H / 24H / weekly)
  - Futures vs spot volume, with a trend line
  - Market sentiment (Fear & Greed) and historical volatility (DVOL)

It runs entirely on your own computer. Nothing is uploaded anywhere. The data comes
from a free service called Coinalyze; you'll make a free account and paste in a key once.

Click any panel's title bar (or the diagonal-arrows icon) to make it full screen.
Each panel has its own little refresh button (circular arrow). The big REFRESH button
at the top refreshes everything. There is no auto-refresh — data updates only when you
ask for it, so you won't run into rate limits.


============================================================
  SETUP  —  about 5 minutes, one time
============================================================

You'll do three things: (1) install Python, (2) get a free Coinalyze key,
(3) start the app and paste the key in once.


------------------------------------------------------------
STEP 1 — Install Python
------------------------------------------------------------
This is the engine the app runs on. It's free.

WINDOWS:
  1. Go to:  https://www.python.org/downloads/
  2. Click the big yellow "Download Python" button and run the installer.
  3. VERY IMPORTANT: on the FIRST installer screen, check the box at the bottom
     that says "Add python.exe to PATH" BEFORE clicking Install. (Skipping this is
     the #1 cause of problems.)
  4. Click "Install Now" and let it finish.

MAC:
  1. Go to:  https://www.python.org/downloads/
  2. Download and run the installer (just keep clicking Continue / Install).
  Note: after installing on a Mac, open the "Python 3.x" folder in your Applications
  and double-click "Install Certificates.command" once. This prevents a common
  error where data won't load. (Takes 5 seconds.)


------------------------------------------------------------
STEP 2 — Get your free Coinalyze API key
------------------------------------------------------------
This is what lets the app pull live exchange data. It's free.

  1. Go to:  https://coinalyze.net  and sign up for a free account.
  2. After logging in, go to:  https://coinalyze.net/account/api-key/
  3. Copy the API key shown there. (Keep this page open; you'll paste it in Step 4.)

  >> Each person needs their OWN free key. Don't share yours — get your own. <<


------------------------------------------------------------
STEP 3 — Put all the files in one folder
------------------------------------------------------------
Make sure these files are all together in a SINGLE folder (e.g. a folder named
"btc-cockpit" on your Desktop):

  - server.py
  - index.html
  - start.bat          (Windows launcher)
  - start.command      (Mac launcher)
  - README.txt         (this file)

If they're scattered in your Downloads, make a new folder and drag them all into it.


------------------------------------------------------------
STEP 4 — Start the app
------------------------------------------------------------
WINDOWS:
  - Double-click  start.bat
  - A black window opens and stays open. You should see a line like:
        ->  open  http://localhost:8765
  - Leave that window open while you use the app. (To stop later: close it,
    or click it and press Ctrl+C.)

  If start.bat flashes and closes, or says "Python was not found", see TROUBLESHOOTING.

MAC:
  - Double-click  start.command
    (The first time, Mac may say it can't open it because it's from an unidentified
     developer. If so: right-click the file > Open > Open. Or open the Terminal app,
     type  cd , then drag the folder onto the window and press Enter, then type:
          python3 server.py   )
  - You should see the "open http://localhost:8765" line. Leave the window open.


------------------------------------------------------------
STEP 5 — Open it and paste your key (one time)
------------------------------------------------------------
  1. Open your web browser and go to:  http://localhost:8765
  2. The first time, a box appears asking for your Coinalyze API key.
     Paste the key you copied in Step 2 and click "Save & connect".
  3. That's it. The key is saved on your computer (in a file called
     coinalyze_key.txt next to the app) and you won't be asked again.

The panels will fill in with live data. Done!


============================================================
  USING IT EVERY DAY
============================================================
  - Start it:  double-click start.bat (Windows) or start.command (Mac),
    then open  http://localhost:8765
  - Stop it:   close the black helper window (or Ctrl+C in it).
  - Refresh one panel: click the small circular-arrow icon in its title bar.
  - Refresh everything: the REFRESH button at the top right.
  - Full-screen a panel: click its title bar; press Esc to shrink it back.


============================================================
  ABOUT THE GREYED-OUT "COINGLASS" PANELS
============================================================
A few tiles (Liquidation Heatmap, Order Flow, Volume Gainers, Exchange Balances)
appear locked. These are NOT active and you do NOT need to do anything about them.

They show data types that no free source provides — they'd require a paid Coinglass
subscription AND extra setup that isn't built into this app. You can safely ignore
them. Everything that actually works is powered by the free Coinalyze data above.

(Short version: don't pay for Coinglass expecting these to turn on. They won't, yet.)


============================================================
  TROUBLESHOOTING
============================================================

"Python was not found" / a Microsoft Store page opens:
  Windows is using a placeholder instead of real Python. Either:
   - In the black window, type  py server.py  instead, OR
   - Reinstall Python from python.org and TICK "Add python.exe to PATH" (Step 1), OR
   - Settings > Apps > Advanced app settings > App execution aliases >
     turn OFF "python.exe" and "python3.exe".

The window flashes and closes instantly:
  Don't double-click server.py directly. Use start.bat (Windows) / start.command (Mac).
  Those keep the window open so you can read any message.

"can't open file ... No such file or directory":
  The launcher and server.py aren't in the same folder, or you ran the command from
  the wrong place. Put all files in one folder and use start.bat / start.command.

A panel says "Couldn't load — rate limit":
  Coinalyze's free plan allows 40 requests per minute. Wait ~30 seconds, then use the
  panel's own refresh button (not refresh-all). The app caches for 60s, so quick repeat
  clicks are free.

A panel says "Couldn't load — check the helper is running":
  The black helper window was closed, or you opened the index.html file directly.
  Always go through  http://localhost:8765  with the helper running.

Mac: data won't load at all / SSL or certificate error:
  Run "Install Certificates.command" from your Applications > Python 3.x folder,
  then restart the helper.

"address already in use" when starting:
  An old copy is still running. Close any other helper windows, or just restart your
  computer, then start it again.

Want more exchanges in the aggregates?
  Open server.py in a text editor and raise the number on the line
  "MAX_EXCHANGES = 5". Note: more exchanges = more API calls, and the free Coinalyze
  limit (40/min) is the practical ceiling. 5 already covers most BTC activity.


============================================================
  NOTES
============================================================
  - Free to run. Each person needs their own free Coinalyze account/key.
  - Your key stays on your own computer; it's only ever sent to Coinalyze.
  - This is a data viewer for your own research. It is NOT financial advice.
